from django.contrib import admin
from django.urls import path
from home import views
from .views import contact_view

urlpatterns = [
    path('', views.index , name = 'home'),
    path('index', views.index , name = 'home'),
    path('contact', views.contact_view, name='contact'),
]
    

