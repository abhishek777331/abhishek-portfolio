from django.shortcuts import render , HttpResponse
from django.core.mail import send_mail


# Create your views here.
def index(request):
    # return HttpResponse("this is home page")
    return render(request , 'index.html')

def contact_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        full_message = f"Name: {name}\nEmail: {email}\nMessage:\n{message}"

        send_mail(
            subject="New Portfolio Contact Message",
            message=full_message,
            from_email=email,
            recipient_list=['abhishek777deoda@gmail.com'],
        )

        return render(request, 'thankyou.html')  # Show thank you page
    return render(request, 'index.html')  # Show form again if not POST
